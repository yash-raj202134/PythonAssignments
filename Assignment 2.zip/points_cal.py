"""This is a simple module to calculate the points for man of the match 
in a cricket match"""

'''Rules 
Batting: 
# 1 point for 2 runs scored 
# Additional 5 points for a half-century 
# Additional 10 points for a century 
# 2 points for strike rate (runs/balls faced) of 80-100 
# Additional 4 points for strike rate>100 
# 1 point for hitting a boundary (four) and 2 points for over boundary (six)

Bowling: 
# 10 points for each wicket 
# Additional 5 points for three wickets in innings 
# Additional 10 points for 5 wickets or more in innings 
# 4 points for economy rate (runs given per over) between 3.5 and 4.5
# 7 points for an economic rate between 2 and 3.5 
# 10 points for an economy rate less than 2

Fielding: 
# 10 points each for catch/stumping/run out '''

# Batting score calculator function
def batting_score(dic):
    bat_score = 0
    strike_rate = 0.0
    bat_score = (dic['runs'])/2
    if dic['runs'] >= 50:
        bat_score += 5
    if dic['runs'] >= 100:
        bat_score += 10
    strike_rate = (dic['runs']/dic['balls'])*100

    if strike_rate >= 80 and strike_rate <= 100:
        bat_score += 2
    elif strike_rate > 100:
        bat_score += 4

    bat_score += dic['4']*1
    bat_score += dic['6']*2
    bat_score = int(bat_score)
    return {'name': dic['name'], 'batscore': bat_score}

# Bowling score calculator function
def bowling_score(dic):
    bowl_score = 0
    econ_rate = 0.0
    bowl_score += dic['wkts']*10
    if dic['wkts'] >= 3:
        bowl_score += 5
    if dic['wkts'] >= 5:
        bowl_score += 10
    econ_rate = dic['runs']/dic['overs']
    if econ_rate >= 3.5 and econ_rate <= 4.5:
        bowl_score += 4
    elif econ_rate >= 2 and econ_rate <= 3.5:
        bowl_score += 7
    elif econ_rate <= 2:
        bowl_score += 10

    return {'name': dic['name'], 'bowlscore': bowl_score}

# Fielding score calculator function
def fielding_score(dic):
    field_score = 0
    field_score += dic['field']*10
    return {'name': dic['name'], 'fieldscore': field_score}


# A general function to call batting or bowling score function
def points(dic):
    if dic['role'] == 'bat':
        return (batting_score(dic))
    else:
        return(bowling_score(dic))
    return
