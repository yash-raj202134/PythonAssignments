'''
Problem Statement: 

Assuming that these are the top 5 performers,
write a Python program to decide the player with the highest points. 
Develop separate functions to compute batting and bowling points and 
save them in a module. These functions should be imported into the main code.''' 

import points_cal as p   # module points_cal is imported

'''The performance of each player is stored in a dictionary object. '''

p1={'name':'Virat Kohli', 'role':'bat', 'runs':112, '4':10, '6':0,
    'balls':119, 'field':0}
p2={'name':'du plessis', 'role':'bat', 'runs':120, '4':11, '6':2,
    'balls':112, 'field':0}
p3={'name':'Bhuvneshwar Kumar', 'role':'bowl', 'wkts':1, 'overs':10,
    'runs':71, 'field':1}
p4={'name':'Yuzvendra Chahal', 'role':'bowl', 'wkts':2, 'overs':10,
    'runs':45, 'field':0}
p5={'name':'Kuldeep Yadav', 'role':'bowl', 'wkts':3, 'overs':10,
    'runs':34, 'field':0}


print(p.points(p1))
print(p.points(p2))
print(p.points(p3))
print(p.points(p4))
print(p.points(p5))
 


